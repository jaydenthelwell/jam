import { Controller } from "@hotwired/stimulus"

// Connects to data-controller="matches"
export default class extends Controller {
  connect() {
    console.log('hello world')
  }


};
